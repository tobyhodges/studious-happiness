for filename in gapminder_gdp_oceania.csv gapminder_gdp_africa.csv
do
   python gdp_plots.py $filename
done
